# Handoff: Visual Variation Tile — editorial refinement

## Overview

The `visual-variation-tile` component inside `wy-prompt-modal.js` currently renders selected tiles with a doubled border (a `border-color` change **plus** a `box-shadow: 0 0 0 1px` offset), and wraps the caption area in its own box border. Together these produce a heavy, card-like feel that conflicts with the editorial hairline vocabulary of The Nineteenth design system.

This handoff documents the fix: three targeted CSS edits that reduce the selection treatment to a single hairline and remove the caption border, making each tile read as an image plate with a floating caption below — not a boxed card.

---

## About the design files

`Visual Variation Tile.dc.html` is a **design reference built in HTML** — a prototype showing the intended before/after appearance and the interactive states (rest, hover, selected). It is **not** production code to copy directly. The task is to apply the documented CSS changes to `wy-prompt-modal.js` in the existing codebase.

## Fidelity

**High-fidelity.** The spec shows exact token values (`--ink`, `--paper-edge`), precise measurements, and the final interaction states. Apply the changes pixel-for-pixel.

---

## What changes

All edits are inside the `static styles = css\`…\`` block of:

```
components/ui/wy-prompt-modal.js
```

### Change 1 — Remove the doubled selection frame

**Find and replace this block in full:**

```css
/* Before */
.visual-variation-tile.selected .visual-variation-media,
.visual-variation-tile.selected .visual-variation-text-tile {
    border-color: var(--ink, #1A1A1A);
    box-shadow: 0 0 0 1px var(--ink, #1A1A1A);
}
```

```css
/* After */
.visual-variation-tile.selected .visual-variation-media {
    border-color: var(--ink, #1A1A1A);
}
```

**Why:** the `box-shadow: 0 0 0 1px` adds a second hairline 1px outside the border, creating a visual 2–3px frame. A single `border-color` change is sufficient and matches the system's "one hairline for authority" rule.

---

### Change 2 — Remove the box border around the caption

**Find `.visual-variation-copy` and remove the `border-top` property:**

```css
/* Before */
.visual-variation-copy {
    display: flex;
    flex-direction: column;
    gap: var(--spacing-xs, 4px);
    padding: var(--spacing-sm, 12px);
    padding-top: 8px;
    margin-top: 10px;
    border-top: 1px solid var(--paper-edge, #DDD6C8);  /* ← remove this line */
    min-width: 0;
}
```

```css
/* After */
.visual-variation-copy {
    display: flex;
    flex-direction: column;
    gap: var(--spacing-xs, 4px);
    padding: var(--spacing-sm, 12px);
    padding-top: 8px;
    margin-top: 10px;
    min-width: 0;
}
```

**Why:** the `border-top` on `.visual-variation-copy` combined with the `border` on `.visual-variation-media` makes the tile look like a two-part boxed card. Removing it lets the caption float below the plate with only whitespace — the editorial pattern throughout The Nineteenth.

---

### Change 3 (optional) — Add a small ink mark as a selected indicator

This gives the selected state a secondary typographic signal in addition to the border change — a 5×5px ink square that appears inline with the variant name. Add to the Lit template inside `_renderVisualVariationTile` (or wherever the name span is rendered):

```js
// Inside the name span, after the name text:
${variation.selected ? html`
  <span style="
    display: inline-block;
    width: 5px;
    height: 5px;
    background: var(--ink, #1A1A1A);
    flex-shrink: 0;
    vertical-align: middle;
    margin-left: 6px;
    margin-bottom: 2px;
  "></span>
` : ''}
```

And update `.visual-variation-name` to use flex so the mark aligns:

```css
.visual-variation-name {
    display: flex;
    align-items: center;
    gap: 6px;           /* ← add */
    color: var(--ink, #1A1A1A);
    font-family: var(--ff-serif);
    font-style: italic;
    font-weight: 500;
    font-size: 1rem;
    line-height: 1.2;
    overflow-wrap: anywhere;
}
```

---

## Interaction states

| State    | `.visual-variation-media` border      | Caption border | Ink mark |
|----------|---------------------------------------|----------------|----------|
| Rest     | `1px solid var(--paper-edge)`         | none           | hidden   |
| Hover    | `1px solid var(--paper-edge)`, opacity `0.88` | none  | hidden   |
| Selected | `1px solid var(--ink)`                | none           | visible  |

---

## Design tokens used

| Token           | Hex       | Role                          |
|-----------------|-----------|-------------------------------|
| `--ink`         | `#1A1A1A` | Selected border + ink mark    |
| `--paper-edge`  | `#DDD6C8` | Rest border                   |
| `--ff-serif`    | Lora      | Variant name (italic 500)     |
| `--ff-sans`     | Inter     | Description text              |

---

## Files

| File | Purpose |
|------|---------|
| `Visual Variation Tile.dc.html` | Interactive before/after design reference. Open in a browser to see both states side by side and click tiles to test selection. |
| `README.md` | This document — the implementation spec. |

**Source file to edit:** `components/ui/wy-prompt-modal.js` in the `mwyuwono/prompt-library` repo.

---

## Verification checklist

After applying changes, confirm:

- [ ] Selecting a tile shows exactly one hairline border (`1px solid #1A1A1A`) — no doubled outline, no box-shadow glow
- [ ] The caption (name + description) has no surrounding box border — only whitespace below the image
- [ ] Non-selected tiles show `1px solid #DDD6C8` on the image only
- [ ] Hover dims the image to ~88% opacity with no border change
- [ ] The selected ink mark (if implemented) appears inline with the name, vertically centred
